package org.javaro.lecture;
 
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
 
class Person{
    String name;
    int number;
    
    Person(String name, int number){
        this.name = name;
        this.number = number;
    }
    
    public String toString() {
        return "No." + this.number + " " + this.name + "님";
    }
}
 
public class Project {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        Queue <Person> q = new LinkedList();
        int number = 1;
        int n;
        
        while(true) {
            System.out.println("===== 영화 대기열 프로그램 =====");
            System.out.println("1.예약 2.입장 3.대기열 출력 4.종료");
            System.out.println("========================");
            System.out.print("번호 입력: ");
            int num = sc.nextInt();
           
            if(num == 1) {
                System.out.println("몇 명 예약하시겠습니까?");
                System.out.print("사람 수 입력: ");
                n = sc.nextInt();
                if(n <= 0) {
                    System.out.println("잘못된 입력입니다.");
                    continue;
                }
                
                sc.nextLine();
                
                for(int i = 0; i < n; i++) {
                    System.out.print((i+1) + "번 째 사람의 이름: ");
                    String name = sc.next();
                    q.offer(new Person(name, number));
                    number++;
                }
            }
            else if(num == 2) {
                System.out.println("몇 명 입장하십니까?");
                System.out.print("사람 수 입력: ");
                n = sc.nextInt();
                if(n <= 0) {
                    System.out.println("잘못된 입력입니다.");
                    continue;
                }
                else if(n > q.size()) {
                    System.out.println("예약된 인원보다 사람 수가 많습니다.");
                    continue;
                }
                
                for(int i = 0; i < n; i++) {
                    Person person = q.poll();
                    System.out.println("예약번호 " + person.number + " " + person.name + "님 입장하십니다.");
                }
                
            }
            else if(num == 3) {
                System.out.println("===== 현재 대기열 =====");
                for(Person v : q) {
                    System.out.println(v);
                }
                System.out.println("===================");
                
            }
            else if(num == 4) {
                System.out.println("프로그램이 종료됩니다...");
                break;
            }
            else {
                System.out.println("잘못된 번호입니다!");
            }
        }
    }
}